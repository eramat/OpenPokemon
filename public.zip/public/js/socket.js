/**
 * Created by boulanger on 14/06/2016.
 */
var socket = io.connect('http://localhost:3000');